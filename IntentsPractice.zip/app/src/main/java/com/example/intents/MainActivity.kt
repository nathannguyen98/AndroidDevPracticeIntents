package com.example.intents

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun goToBrowser(view: View){
        //Find button and assign it to b1
        b1 = findViewById<Button>(R.id.myButton)
        //set a onClick listener for our button
        b1!!.setOnClickListener(View.OnClickListener {
            //Create a new intent
            val i = Intent(
                    Intent.ACTION_VIEW,
                    //The URI we want to pass (can be anything)
                    Uri.parse("https://www.qa.com")
            )
            //Finally start the activity passing in i as an argument.
            startActivity(i)
        })
    }




}